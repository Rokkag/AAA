# Pawchive — Tachiyomi / Mihon Extension

A Tachiyomi-compatible source extension for **Pawchive**, a kemono-style
creator-archive site that mirrors subscription content from Patreon, Pixiv Fanbox,
Subscribestar, Gumroad, Discord, DLsite, Boosty, and more.

> ⚠️  This extension is marked **NSFW**. It will only appear in Tachiyomi / Mihon
> when the "Show NSFW sources" option is enabled in Settings → Browse.

---

## Conceptual mapping

| Pawchive concept | Tachiyomi concept |
|---|---|
| Creator profile  | Manga / Series |
| Post             | Chapter |
| Attached image   | Page |

---

## Features

| Feature | Status |
|---|---|
| Browse popular creators (by last updated) | ✅ |
| Latest updates feed (de-duped per creator) | ✅ |
| Search creators by name | ✅ |
| Filter by platform (Patreon, Fanbox, …) | ✅ |
| Filter by tag | ✅ |
| Sort results (updated / name / favourited) | ✅ |
| Full chapter list with auto-pagination | ✅ |
| Image pages from post attachments | ✅ |
| Creator avatar thumbnails | ✅ |
| Deep-link from browser → reader | ✅ |
| Video / text post graceful skip | ✅ |
| Rate limiting (2 req/s) | ✅ |
| Cloudflare bypass | ✅ |

---

## Project structure

```
pawchive-extension/
├── AndroidManifest.xml           # Deep-link intent-filter for pawchive.net
├── build.gradle                  # Extension metadata & Gradle config
├── README.md                     # This file
└── src/
    └── eu/kanade/tachiyomi/extension/en/pawchive/
        ├── Pawchive.kt           # Main HttpSource — all API logic lives here
        ├── PawchiveDto.kt        # Kotlinx-serialization data classes
        ├── PawchiveFilters.kt    # Filter / sort / tag filter definitions
        └── PawchiveUrlActivity.kt# Trampoline that handles web deep-links
```

---

## Building from source

### Prerequisites

* JDK 17+
* Android SDK (API 34)
* The official **tachiyomi-extensions** (or **mihon-extensions**) repository
  cloned locally — this extension lives inside that repo's module structure.

```
# 1. Clone the extensions monorepo
git clone https://github.com/mihonapp/extensions-source.git
cd extensions-source

# 2. Drop this folder into the right place
cp -r /path/to/pawchive-extension  src/en/pawchive/

# 3. Build just this extension
./gradlew :src:en:pawchive:assembleDebug

# 4. The signed debug APK ends up at
#   src/en/pawchive/build/outputs/apk/debug/tachiyomi-en.pawchive-v1-debug.apk
```

### Installing the APK

Transfer the APK to your Android device and install it, or use ADB:

```bash
adb install src/en/pawchive/build/outputs/apk/debug/tachiyomi-en.pawchive-v1-debug.apk
```

Then in Tachiyomi / Mihon:

1. **Browse → Sources** — Pawchive will appear under "English".
2. Tap the globe icon to browse, or use the magnifier to search.

---

## API endpoints used

All requests go to `https://pawchive.net/api/v1`.

| Method | Path | Used for |
|---|---|---|
| `GET` | `/creators?sort=updated&o=N` | Popular creators (paginated) |
| `GET` | `/posts?o=N` | Latest updates feed |
| `GET` | `/creators/search?q=…&service=…&sort=…&o=N` | Search |
| `GET` | `/creators/{service}/{id}` | Creator detail |
| `GET` | `/{service}/user/{id}/posts?o=N&limit=50` | Chapter list (paginated) |
| `GET` | `/{service}/post/{id}` | Page list for one post |

---

## Adapting to a different base URL

Change `baseUrl` at the top of `Pawchive.kt`:

```kotlin
override val baseUrl = "https://your-mirror.example.com"
```

If the site also changes its API prefix, update `apiUrl` accordingly.

---

## Caveats

* **Posts without images** (text-only, video embeds) will show an error in the
  reader explaining there are no readable pages. This is intentional.
* Attachments are filtered to common image extensions (`.jpg`, `.png`, `.gif`,
  `.webp`, `.avif`, `.bmp`, `.tiff`). Other file types (ZIPs, PDFs, MP4s) are
  silently skipped.
* The Cloudflare interceptor may require a brief WebView challenge the very first
  time the source is used. This is handled automatically by the Tachiyomi network
  layer.

---

## License

Apache 2.0 — same as the upstream tachiyomi-extensions repository.
